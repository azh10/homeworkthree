Harold Marcial
Anthony Ansag

To run the program on Eustis server.
gcc parser.c
./a.out 		//If you want to not print the lexemelist
./a.out -l		//If you want to print the lexemelist